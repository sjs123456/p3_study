# !/usr/bin/env python
# -*- coding:utf-8 -*-
# author : sjs

import re

com = re.compile('\(\)')

s = '(3/5)'
# print(com.search(s).group())

ret = re.findall(r'\(\S\)', s)
print(ret)